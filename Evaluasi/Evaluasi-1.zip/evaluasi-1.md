## Evaluasi 1

1. Buatlah program konversi suhu ke dalam satuan kelvin, fahrenheit, dan reaumur, kemudian simpan dengan nama latihan-5.php (Semakin banyak fitur semakin bagus).

2. Buatlah program penghitungan seperti kalkulator, kemudian simpan dengan nama latihan-6.php (Semakin banyak fitur semakin bagus).


# Catatan :

## Jangan mau hanya menjadi biasa-biasa saja dalam mengerjakan suatu hal, buatlah sesuatu dengan cara efisin, dan seefektif mungkin

**Kejarlah nilai sempurna**

## Ketentuan dan peraturan selama mengerjakan :

* Kosongkan setiap tab pada code editor masing-masing, dicode editor hanya ada
* Manfaatkan waktu 5 menit terakhir untuk push ke repository masing-masing di github
* Kerjakan dengan jujur dan penuh keyakinan
* Jangan pesimis dan OPTIMIS lah
* Jangan Banyak Ngeluh
* 1 menit sebelum mengerjakan evaluasi harap dipersiapkan folder dan
  `file.php`, jika terlambat maka tanggung resiko nya dan terpaksa harus
  ditinggalkan

* Manfaatkan stackoverflow, w3school, dan php.net sebagai teman yang baik dalam
  mengerjakan setiap soal
* Dilarang keras untuk bekerja sama
* Run program timer saat ujian dimulai
* Idealis lah dengan diri sendiri jangan mau ketinggalan
* FOKUS!!!

